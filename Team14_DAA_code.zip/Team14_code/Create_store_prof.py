from professor_classes import *

professor_list = []
# n = int(input('Enter the number of courses/Professor for the batch : '))
#
# for i in range(n):
#     print('-----------------------------')
#     print('Professor {}'.format(i + 1))
#     print('-----------------------------')
#     a_prof = create_professor()
#     a_prof.display_prof()
#     professor_list.append(a_prof)

prof1 = Professor(name="G Ram Mohan Reddy", sub="DAA", course_code='IT257')
prof1.work.weekdays[0].time_slots = [(9, 12)]
prof1.work.weekdays[1].time_slots = [(1, 4)]
prof1.work.weekdays[2].time_slots = [(10, 12), (1, 2)]
prof1.work.weekdays[3].time_slots = [(9, 11)]
prof1.work.weekdays[4].time_slots = [(1, 3)]
prof1.work.weekdays[0].preference_list = [1, 2, 4, 3]
prof1.work.weekdays[1].preference_list = [4, 3, 1, 2]
prof1.work.weekdays[2].preference_list = [2, 3, 1, 4]
prof1.work.weekdays[3].preference_list = [1, 2, 3, 4]
prof1.work.weekdays[4].preference_list = [3, 4, 1, 2]
avail_hours = []
prof1.work.weekdays[0].available_hours = prof1.work.weekdays[0].calculate_available_hours()
avail_hours.append(prof1.work.weekdays[0].available_hours)
prof1.work.weekdays[1].available_hours = prof1.work.weekdays[1].calculate_available_hours()
avail_hours.append(prof1.work.weekdays[1].available_hours)
prof1.work.weekdays[2].available_hours = prof1.work.weekdays[2].calculate_available_hours()
avail_hours.append(prof1.work.weekdays[2].available_hours)
prof1.work.weekdays[3].available_hours = prof1.work.weekdays[3].calculate_available_hours()
avail_hours.append(prof1.work.weekdays[3].available_hours)
prof1.work.weekdays[4].available_hours = prof1.work.weekdays[4].calculate_available_hours()
avail_hours.append(prof1.work.weekdays[4].available_hours)
professor_list.append((prof1, avail_hours))
prof1.display_prof()

prof2 = Professor(name="Sowmya Kamath", sub="DS", course_code='IT258')
prof2.work.weekdays[0].time_slots = [(9, 11), (2, 4)]
prof2.work.weekdays[1].time_slots = [(9, 10)]
prof2.work.weekdays[2].time_slots = [(1, 3)]
prof2.work.weekdays[3].time_slots = [(10, 12)]
prof2.work.weekdays[4].time_slots = [(9, 12), (1, 4)]
prof2.work.weekdays[0].preference_list = [1, 3, 2, 4]
prof2.work.weekdays[1].preference_list = [1, 2, 4, 3]
prof2.work.weekdays[2].preference_list = [3, 4, 1, 2]
prof2.work.weekdays[3].preference_list = [2, 3, 4, 1]
prof2.work.weekdays[4].preference_list = [1, 2, 3, 4]
avail_hours = []
prof2.work.weekdays[0].available_hours = prof2.work.weekdays[0].calculate_available_hours()
avail_hours.append(prof2.work.weekdays[0].available_hours)
prof2.work.weekdays[1].available_hours = prof2.work.weekdays[1].calculate_available_hours()
avail_hours.append(prof2.work.weekdays[1].available_hours)
prof2.work.weekdays[2].available_hours = prof2.work.weekdays[2].calculate_available_hours()
avail_hours.append(prof2.work.weekdays[2].available_hours)
prof2.work.weekdays[3].available_hours = prof2.work.weekdays[3].calculate_available_hours()
avail_hours.append(prof2.work.weekdays[3].available_hours)
prof2.work.weekdays[4].available_hours = prof2.work.weekdays[4].calculate_available_hours()
avail_hours.append(prof2.work.weekdays[4].available_hours)
professor_list.append((prof2, avail_hours))
prof2.display_prof()


prof3 = Professor(name="Nagamma Patil", sub="LA", course_code='IT256')
prof3.work.weekdays[0].time_slots = [(1, 4)]
prof3.work.weekdays[1].time_slots = [(10, 12)]
prof3.work.weekdays[2].time_slots = [(9, 10), (1, 3)]
prof3.work.weekdays[3].time_slots = [(10, 12), (1, 4)]
prof3.work.weekdays[4].time_slots = [(9, 10)]
prof3.work.weekdays[0].preference_list = [4, 3, 2, 1]
prof3.work.weekdays[1].preference_list = [2, 3, 4, 1]
prof3.work.weekdays[2].preference_list = [1, 3, 4, 2]
prof3.work.weekdays[3].preference_list = [2, 3, 4, 1]
prof3.work.weekdays[4].preference_list = [1, 2, 3, 4]
avail_hours = []
prof3.work.weekdays[0].available_hours = prof3.work.weekdays[0].calculate_available_hours()
avail_hours.append(prof3.work.weekdays[0].available_hours)
prof3.work.weekdays[1].available_hours = prof3.work.weekdays[1].calculate_available_hours()
avail_hours.append(prof3.work.weekdays[1].available_hours)
prof3.work.weekdays[2].available_hours = prof3.work.weekdays[2].calculate_available_hours()
avail_hours.append(prof3.work.weekdays[2].available_hours)
prof3.work.weekdays[3].available_hours = prof3.work.weekdays[3].calculate_available_hours()
avail_hours.append(prof3.work.weekdays[3].available_hours)
prof3.work.weekdays[4].available_hours = prof3.work.weekdays[4].calculate_available_hours()
avail_hours.append(prof3.work.weekdays[4].available_hours)
professor_list.append((prof3, avail_hours))
prof3.display_prof()


prof4 = Professor(name="Sujan Gowda", sub="AI", course_code='IT255')
prof4.work.weekdays[0].time_slots = [(9, 10), (1, 2)]
prof4.work.weekdays[1].time_slots = [(2, 4)]
prof4.work.weekdays[2].time_slots = [(9, 10), (1, 2)]
prof4.work.weekdays[3].time_slots = [(1, 4)]
prof4.work.weekdays[4].time_slots = [(9, 12)]
prof4.work.weekdays[0].preference_list = [1, 3, 2, 4]
prof4.work.weekdays[1].preference_list = [4, 3, 1, 2]
prof4.work.weekdays[2].preference_list = [1, 3, 2, 4]
prof4.work.weekdays[3].preference_list = [3, 4, 1, 2]
prof4.work.weekdays[4].preference_list = [2, 1, 3, 4]
avail_hours = []
prof4.work.weekdays[0].available_hours = prof4.work.weekdays[0].calculate_available_hours()
avail_hours.append(prof4.work.weekdays[0].available_hours)
prof4.work.weekdays[1].available_hours = prof4.work.weekdays[1].calculate_available_hours()
avail_hours.append(prof4.work.weekdays[1].available_hours)
prof4.work.weekdays[2].available_hours = prof4.work.weekdays[2].calculate_available_hours()
avail_hours.append(prof4.work.weekdays[2].available_hours)
prof4.work.weekdays[3].available_hours = prof4.work.weekdays[3].calculate_available_hours()
avail_hours.append(prof4.work.weekdays[3].available_hours)
prof4.work.weekdays[4].available_hours = prof4.work.weekdays[4].calculate_available_hours()
avail_hours.append(prof4.work.weekdays[4].available_hours)
professor_list.append((prof4, avail_hours))
prof4.display_prof()


# prof5 = Professor(name="Bhawana Rudra", sub="QC", course_code='IT437')
# prof5.work.weekdays[0].time_slots = [(9, 12)]
# prof5.work.weekdays[1].time_slots = [(9, 10), (2, 4)]
# prof5.work.weekdays[2].time_slots = [(9, 10)]
# prof5.work.weekdays[3].time_slots = [(9, 10), (1, 4)]
# prof5.work.weekdays[4].time_slots = [(9, 10)]
# prof5.work.weekdays[0].preference_list = [1, 3, 2, 4]
# prof5.work.weekdays[1].preference_list = [4, 3, 1, 2]
# prof5.work.weekdays[2].preference_list = [1, 3, 2, 4]
# prof5.work.weekdays[3].preference_list = [1, 3, 4, 2]
# prof5.work.weekdays[4].preference_list = [1, 2, 3, 4]
# avail_hours = []
# prof5.work.weekdays[0].available_hours = prof5.work.weekdays[0].calculate_available_hours()
# avail_hours.append(prof5.work.weekdays[0].available_hours)
# prof5.work.weekdays[1].available_hours = prof5.work.weekdays[1].calculate_available_hours()
# avail_hours.append(prof5.work.weekdays[1].available_hours)
# prof5.work.weekdays[2].available_hours = prof5.work.weekdays[2].calculate_available_hours()
# avail_hours.append(prof5.work.weekdays[2].available_hours)
# prof5.work.weekdays[3].available_hours = prof5.work.weekdays[3].calculate_available_hours()
# avail_hours.append(prof5.work.weekdays[3].available_hours)
# prof5.work.weekdays[4].available_hours = prof5.work.weekdays[4].calculate_available_hours()
# avail_hours.append(prof5.work.weekdays[4].available_hours)
# professor_list.append((prof5, avail_hours))
# prof5.display_prof()


full_professor_dic = {
    1 : {'Professor name' : 'G Ram Mohan Reddy', 'Course': 'DAA' , 'Course code' : 'IT257'},
    2 : {'Professor name' : 'Sowmya Kamath', 'Course' :'DS' , 'Course code' : 'IT258'},
    3 : {'Professor name' : 'Nagamma Patil', 'Course' : 'LA', 'Course code' : 'IT256'},
    4 : {'Professor name' : 'Sujan Gowda', 'Course' : 'AI', 'Course code' : 'IT255'},
    5 : {'Professor name' : 'Bhawana Rudra', 'Course' : 'QC  SE', 'Course code' : 'IT437  IT303'},
    6 : {'Professor name' : 'Shrutilipi Bhattacharjee', 'Course': 'DSA  DAA' , 'Course code' : 'IT251  IT300'},
    7 : {'Professor name' : 'Geetha V', 'Course' : 'ACD  PC', 'Course code' : 'IT250  IT301'},
    8 : {'Professor name' : 'Anand Kumar', 'Course' : 'PS', 'Course code' : 'IT302'},
    9 : {'Professor name' : 'Anupama', 'Course' : 'OS', 'Course code' : 'IT253'},
    10 : {'Professor name' : 'Vasudev', 'Course' : 'WEB', 'Course code' : 'IT254'},
    11 : {'Professor name' : 'Anitha S R', 'Course' : 'DBMS', 'Course code' : 'IT252'}
}

greedy_dic2 = {'Monday':{1:'OS',2:'ACD',3:'WEB',4:'DBMS'},
'Tuesday':{1:'DBMS',2:'OS',3:'DSA'},
'Wednesday':{1:'WEB',2:'ACD',3:'DSA'},
'Thursday':{1:'DBMS',2:'ACD',3:'WEB'},
'Friday':{1:'DSA',2:'OS'}}

greedy_df2 = (pd.DataFrame(greedy_dic2, index=[1, 2, 3, 4]).transpose())
greedy_df2.columns = ['(9:00 - 10:30)', '(10:30 - 12:00)', '(1:00 - 2:30)', '(2:30 - 4:00)']


