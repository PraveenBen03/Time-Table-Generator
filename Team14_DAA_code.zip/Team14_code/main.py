import time
from displayManager import displayManager
from data import Data
from schedule import population
from geneticAlgorithm import geneticAlgorithm
import tkinter as tk
import pandas as pd

class TimeTableApp:
    def __init__(self, root, data):
        self.root = root
        self.root.title("Time Table")

        self.table_frame = tk.Frame(self.root)
        self.table_frame.pack(pady=10)

        self.data = data

        self.create_table()

    def create_table(self):
        # Create table headings
        headings = ["Time", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
        for i, heading in enumerate(headings):
            label = tk.Label(self.table_frame, text=heading, font=('Arial', 12, 'bold'))
            label.grid(row=0, column=i, padx=10, pady=5)

        # Create table rows with existing data
        for i, row in enumerate(self.data):
            for j, cell in enumerate(row):
                label = tk.Label(self.table_frame, text=cell, font=('Arial', 12))
                label.grid(row=i+1, column=j, padx=10, pady=5)


startTime = time.time()

popSize = 10
data = Data()
disp = displayManager(data)
disp.printAvailableData()
gen = 0
ans = [[]]
print("\nGENERATION " + str(gen))
pop = population(popSize, data)
pop.getSchedule().sort(key=lambda x: x.getFitness(), reverse=True)

disp.printGeneration(pop)
print(pop.getSchedule()[0])
ans = disp.printSchedule(pop.getSchedule()[0])

numberOfEliteSchedule = 1
tournamentSelectionSize = 3
mutationRate = 0.1

ga = geneticAlgorithm(numberOfEliteSchedule, popSize, mutationRate, tournamentSelectionSize, data)
dictt_prof_subjects = {0:"DAA",1:"DS",2:"QC",3:"LA",4:"AI"}
nums_to_timings = {0:"08:00-09:00",1:"09:00-10:00",2:"10:00-11:00",3:"11:00-12:00",4:"13:00-14:00"}
data1 = [["9:00 - 10:00",None,None,None,None,None,None],["10:00 - 11:00",None,None,None,None,None,None],["11:00 - 12:00",None,None,None,None,None,None],["12:00 - 13:00",None,None,None,None,None,None],["13:00 - 14:00",None,None,None,None,None,None]]
while pop.getSchedule()[0].getFitness() != 1.0:
    gen += 1
    print("Generation {}".format(gen))
    pop = ga.evolve(pop)
    pop.getSchedule().sort(key=lambda x: x.getFitness(), reverse=True)
    disp.printGeneration(pop)
    ans = disp.printSchedule(pop.getSchedule()[0])
for i in ans:
    print(i)
    pl = i[2]
    print(pl)
    days = []
    if 'M' in i[5] : days.append(1)
    if 'T' in i[5] : days.append(2)
    if 'W' in i[5] : days.append(3)
    if 'Th' in i[5] : days.append(4)
    if 'F' in i[5] : days.append(5)
    if 'S' in i[5] : days.append(6)

    if "09:00-10:30" in i[5]:
        for j in days:
            print(j)
            data1[0][j] = pl
    if "10:30-12:00" in i[5]:
        for j in days:
            data1[1][j] = pl
    if "1:00-2:30" in i[5]:
        for j in days:
            print(j)
            data1[2][j] = pl
    if "2:30-4:00" in i[5]:
        for j in days:
            data1[3][j] = pl
    if "13:00-14:00" in i[5]:
        for j in days:
            data1[3][j] = pl
    print(days)
# root = tk.Tk()
# app = TimeTableApp(root, data1)
# root.mainloop()
print(data1)


def get_sample_dic1(data):
    data_dic = {}
    for hours in data:
        data_dic[hours[0]] = hours[1:]
    return data_dic


# data_dic = get_sample_dic1(data1)
# gen_df = pd.DataFrame(data_dic, index=['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'])
# gen_df = gen_df.drop('13:00 - 14:00', axis=1)
# gen_df = gen_df.drop('Saturday', axis=0)
# print(gen_df)
# print("Execution time: {} seconds".format(time.time()-startTime))

gen_dic = {'Monday':{1:'LA',2:'DS',3:'QC',4:'DAA'},
'Tuesday':{1:'AI',3:'LA',4:'DAA'},
'Wednesday':{1:'AI',2:'DS',4:'DAA'},
'Thursday':{1:'AI',3:'LA',4:'DAA'},
'Friday':{1:'QC',4:'DAA'}}

gen_df = (pd.DataFrame(gen_dic, index=[1, 2, 3, 4]).transpose())
gen_df.columns = ['(9:00 - 10:30)', '(10:30 - 12:00)', '(1:00 - 2:30)', '(2:30 - 4:00)']


greedy_dic3 = {'Monday':{1:'PC',2:'DAA',3:'PS'},
'Tuesday':{1:'SE',2:'DAA',3:'PC'},
'Wednesday':{1:'PC',2:'DAA',3:'PS'},
'Thursday':{1:'PS',2:'DAA',3:'PC'},
'Friday':{1:'PS',2:'SE'}}

greedy_df3 = (pd.DataFrame(greedy_dic3, index=[1, 2, 3, 4]).transpose())
greedy_df3.columns = ['(9:00 - 10:30)', '(10:30 - 12:00)', '(1:00 - 2:30)', '(2:30 - 4:00)']