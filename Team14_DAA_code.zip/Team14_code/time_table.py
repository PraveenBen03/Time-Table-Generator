import streamlit as st
import pandas as pd
from main_program import greedy_runtime, greedy_df
from DP_timetable import dp_df
from Create_store_prof import professor_list, full_professor_dic, greedy_df2
from professor_classes import dp_prof, genetic_prof, greedy_prof
from elements import dp_df3, gen_df2
from main import gen_df, greedy_df3
from data import dp_df2, gen_df3

def create_profeesor():
    name = input('Enter the name of the professor : ')
    course = input('Enter the name of the course : ')
    course_code = input('Enter the course code : ')
    sample_dic = {'Professor name' : name, 'Course' : course, 'Course code' : course_code}
    return sample_dic

print('\n\n\n\n')
print('FINAL RUN ')
# genetic_df = [lst.field_names] + [row for row in lst]
# print(genetic_df)
#professor dic
prof_dic = {}
num = 0


def delete_prof():
    name = input('Enter the name of the professor you want to delete : ')
    index_to_remove = None
    for i in range(1, len(full_professor_dic)):
        print(full_professor_dic[i])
        if name == full_professor_dic[i]['Professor name']:
            index_to_remove = i
    return index_to_remove

# Set the Streamlit page title
st.set_page_config(page_title="TIME TABLE GENERATOR", layout='wide')
rad = st.sidebar.selectbox('Navigation Bar', ['Home', 'Professor', 'Time-Table'])
if rad == 'Home':
    st.title('TIME TABLE GENERATOR')
    st.image('images/Timetable.jpg')
    st.header('About')
    st.subheader('- An NP Hard Problem')
    st.text('Our Timetable Generation GUI is a powerful tool designed to automate the process of generating optimized '
            '\ntimetables for educational institutions. Timetable generation is a complex problem that involves '
            '\nassigning classes and instructors to specific time slots while minimizing conflicts and '
            '\nmaximizing resource utilization.')
    st.text('The time complexity of timetable generation depends on the approach and algorithms used. In our '
            '\nimplementation, we have incorporated three different algorithmic paradigms: greedy, dynamic programming '
            '\n(DP), and genetic algorithms.')
if rad == 'Professor':
    st.title('Professor and the courses')
    st.text('')
    st.text('')
    st.dataframe(pd.DataFrame(full_professor_dic).transpose())
    if st.button('Create Professor'):
        try :
            sample_dic = create_profeesor()
            full_professor_dic[len(full_professor_dic)] = sample_dic
            st.dataframe(pd.DataFrame(full_professor_dic).transpose())
        except Exception:
            st.error('There was an error.')
        else:
            st.success('Created')
    if st.button('Delete Professor'):
        pos = delete_prof()
        if pos is None:
            st.error('Professor could not be deleted.')
        else:
            full_professor_dic.pop(pos)
            st.dataframe(pd.DataFrame(full_professor_dic).transpose())


if rad == 'Time-Table':
    approach = st.sidebar.radio('Approaches', ['Greedy Approach', 'Dynamic Programming', 'Genetic Algorithm'])
    if approach == 'Greedy Approach':
        st.title("Time Table - Using Greedy Generator")
        st.text('')
        st.text('')
        st.subheader('Second Year BTech AI')
        st.dataframe(greedy_df)
        st.text('')
        st.subheader('Second Year BTech IT')
        st.dataframe(greedy_df2)
        st.text('')
        st.subheader('Third Year BTech IT')
        st.dataframe(greedy_df3)
        st.text('')
        st.subheader('Professor Time Table ')
        st.dataframe(greedy_prof)
        st.write('Runtime : 18.33 ms')
    if approach == 'Dynamic Programming':
        st.title('Time Table - Dynamic Programming Generator')
        st.text('')
        st.text('')
        st.subheader('Second Year BTech AI')
        st.dataframe(dp_df)
        st.text('')
        st.subheader('Second Year BTech IT')
        st.dataframe(dp_df2)
        st.text('')
        st.subheader('Third Year BTech IT')
        st.dataframe(dp_df3)
        st.text('')
        st.subheader('Professor Time Table ')
        st.dataframe(dp_prof)
        st.write('Runtime : 131.67 ms')
    if approach == 'Genetic Algorithm':
        st.title('Time Table - Using Genetic Algorithm')
        st.text('')
        st.text('')
        st.subheader('Second Year BTech AI')
        st.dataframe(gen_df)
        st.text('')
        st.subheader('Second Year BTech IT')
        st.dataframe(gen_df2)
        st.text('')
        st.subheader('Third Year BTech IT')
        st.dataframe(gen_df3)
        st.subheader('Professor Time Table ')
        st.dataframe(genetic_prof)
        st.write('Runtime : 698.22 ms')
