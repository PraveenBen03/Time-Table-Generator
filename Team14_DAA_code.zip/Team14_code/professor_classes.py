import pandas as pd

weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']

class Professor_attributes:
    def __init__(self, time_slots = None, preference_list = None):
        '''time slots are going to be list of tuples and in the tuple it is going to be starting and ending times.
        preference list is a list of the professors' preferences.'''
        self.time_slots = time_slots
        self.preference_list = preference_list
        self.available_hours = 0

    def calculate_available_hours(self):
        total_time = 0
        for i, j in self.time_slots:
            total_time += (j - i)
        return total_time


class Weekday:
    def __init__(self):
        self.monday = Professor_attributes()
        self.tuesday = Professor_attributes()
        self.wednesday = Professor_attributes()
        self.thursday = Professor_attributes()
        self.friday = Professor_attributes()
        self.weekdays = self.put_in_a_list()

    def put_in_a_list(self):
        self.lst = []
        self.lst.append(self.monday)
        self.lst.append(self.tuesday)
        self.lst.append(self.wednesday)
        self.lst.append(self.thursday)
        self.lst.append(self.friday)
        return self.lst


class Professor:
    def __init__(self, name, sub, course_code):
        self.name = name
        self.sub = sub
        self.course_code = course_code
        self.work = Weekday()

    def display_prof(self):
        print('---------------------------')
        print(self.name)
        print('---------------------------')
        days_dict = {}
        for day in range(5):
            days_dict[weekdays[day]] = {'Time_slots': self.work.weekdays[day].time_slots, 'Available Hours': self.work.weekdays[day].available_hours, 'Preference_list': self.work.weekdays[day].preference_list}
        df = pd.DataFrame(days_dict)
        print(df)


def create_professor():
    name = input('Enter the name of the professor : ')
    sub = input('Enter the subject / subjects taught by the professor : ')
    course_code = input('Enter the course for the subject {}'.format(sub))
    prof = Professor(name, sub, course_code)
    for day in range(len(weekdays)):
        print('---------------------------')
        print('Input for {}'.format(weekdays[day]))
        print('---------------------------')
        time_slots = []
        resp = input('Is available in the morning ?')
        if resp == 'yes':
            time_slot = tuple(list(map(int, input('Enter the availability timings : ').split())))
            time_slots.append(time_slot)
        resp = input('Is available in the afternoon ?')
        if resp == 'yes':
            time_slot = tuple(list(map(int, input('Enter the availability timings : ').split())))
            time_slots.append(time_slot)
        preference_list = list(map(int, input('Enter the order of slots preferred (1, 2, 3, 4) : ').split()))
        prof.work.weekdays[day].time_slots = time_slots
        prof.work.weekdays[day].preference_list = preference_list
        prof.work.weekdays[day].available_hours = prof.work.weekdays[day].calculate_available_hours()
    available_hours = []
    for i in range(5):
        available_hours.append(prof.work.weekdays[i].available_hours)
    return prof, available_hours


dp_prof = {
    'Monday' : {'G Ram Mohan Reddy' : None, 'Sowmya Kamath' : 'DS - (10:30 - 12:00)', 'Nagamma Patil' : 'LA - (2:30 - 4:00)', 'Sujan Gowda' : 'AI - (9:00-10:30)', 'Bhawana Rudra' : 'SE - (9:00-10:30), QC - (1:00-2:30)', 'Shrutilipi Bhattacharjee' : 'DAA - (10:30-12:00)', 'Geetha V' : 'PC - (1:00-2:30)\n ACD - (2:30-4:00)', 'Anand Kumar' : 'PS - (2:30-4:00)', 'Anupama' : 'OS - (10:30-12:00)', 'Vasudev' : 'WEB - (1:00-2:30)', 'Anitha' : None},
    'Tuesday' :{'G Ram Mohan Reddy' : None, 'Sowmya Kamath' : 'DS - (10:30 - 12:00)', 'Nagamma Patil' :'LA - (9:00 - 10:30)' , 'Sujan Gowda' : 'AI - (2:30-4:00)', 'Bhawana Rudra' : 'SE - (9:00-10:30), QC - (1:00-2:30)', 'Shrutilipi Bhattacharjee' : 'DSA - (9:00-12:00), DAA - (1:00-2:30)' , 'Geetha V' : 'PC - (10:30-12:00)', 'Anand Kumar' : 'PS - (2:30-4:00)', 'Anupama' : 'OS - (1:00-2:30)', 'Vasudev' : 'WEB - (2:30-4:00)', 'Anitha' : None},
    'Wednesday' : {'G Ram Mohan Reddy' : None, 'Sowmya Kamath' : None, 'Nagamma Patil' :'LA - (9:00 - 10:30)' , 'Sujan Gowda' : 'AI - (10:30-12:00)', 'Bhawana Rudra' : None,'Shrutilipi Bhattacharjee' : 'DAA - (10:30-12:00)' , 'Geetha V' : 'PC - (9:00-10:30)', 'Anand Kumar' : None, 'Anupama' : 'OS - (2:30-4:00)', 'Vasudev' : None, 'Anitha' : 'DBMS - (1:00-2:30)'},
    'Thursday' : {'G Ram Mohan Reddy' : None, 'Sowmya Kamath' : None, 'Nagamma Patil' :None , 'Sujan Gowda' : None, 'Bhawana Rudra' : 'SE - (10:30-12:00), QC - (1:00-2:30)','Shrutilipi Bhattacharjee' : None , 'Geetha V' : 'ACD - (2:30-4:00)', 'Anand Kumar' : 'PS - (9:00-10:30)', 'Anupama' : None, 'Vasudev' : None, 'Anitha' : 'DBMS - (1:00-2:30)'},
    'Friday' : {'G Ram Mohan Reddy' : 'DAA - (10:30-12:00)', 'Sowmya Kamath' : None, 'Nagamma Patil' :None , 'Sujan Gowda' : None, 'Bhawana Rudra' : 'SE - (10:30-12:00)','Shrutilipi Bhattacharjee' : 'DAA - (1:00-2:30)' , 'Geetha V' : 'PC - (9:00-10:30)', 'Anand Kumar' : 'PS - (2:30-4:00)', 'Anupama' : None, 'Vasudev' : 'WEB - (10:30-12:00)', 'Anitha' : 'DBMS - (2:30-4:00)'}
}

greedy_prof = {
    'Monday' : {'G Ram Mohan Reddy' : 'DAA - (10:30-12:00)', 'Sowmya Kamath' : 'DS - (2:30-4:00)', 'Nagamma Patil' : 'LA - (1:00-2:30)', 'Sujan Gowda' : 'AI - (9:00-10:30)', 'Bhawana Rudra' : None, 'Shrutilipi Bhattacharjee' : 'DAA - (10:30-12:00)', 'Geetha V' : 'PC - (9:00-10:30), ACD - (10:30-12:00)', 'Anand Kumar' : 'PS - (1:00-2:30)', 'Anupama' : 'OS - (9:00-10:30)', 'Vasudev' : 'WEB - (1:00-2:30)', 'Anitha' : 'DBMS - (2:30-4:00)'},
    'Tuesday' :{'G Ram Mohan Reddy' : 'DAA - (2:30-4:00)', 'Sowmya Kamath' : 'DS - (9:00-10:30)', 'Nagamma Patil' :'LA - (10:30-12:00)' , 'Sujan Gowda' : 'AI - (1:00-2:30)', 'Bhawana Rudra' : 'SE - (9:00-10:30)', 'Shrutilipi Bhattacharjee' : 'DSA - (1:00-2:30), DAA - (10:30-12:00)' , 'Geetha V' : 'PC - (1:00-2:30)', 'Anand Kumar' : 'PS - (2:30-4:00)', 'Anupama' : 'OS - (10:30-12:00)', 'Vasudev' : None, 'Anitha' : 'DBMS - (9:00-10:30)'},
    'Wednesday' : {'G Ram Mohan Reddy' : 'DAA - (10:30-12:00)', 'Sowmya Kamath' : 'DS - (2:30-4:00)', 'Nagamma Patil' :'LA - (1:00-2:30)' , 'Sujan Gowda' : 'AI - (9:00-10:30)', 'Bhawana Rudra' : None,'Shrutilipi Bhattacharjee' : 'DSA - (1:00-2:30), DAA - (10:30-12:00)' , 'Geetha V' : 'PC - (9:00-10:30), ACD - (10:30-12:00)', 'Anand Kumar' : 'PS - (1:00-2:30)', 'Anupama' : None, 'Vasudev' : 'WEB - (9:00-10:30)', 'Anitha' : None},
    'Thursday' : {'G Ram Mohan Reddy' : 'DAA - (9:00-10:30)', 'Sowmya Kamath' : 'DS - (10:30-12:00)', 'Nagamma Patil' :'LA - (1:00-2:30)' , 'Sujan Gowda' : 'AI - (2:30-4:00)', 'Bhawana Rudra' : None,'Shrutilipi Bhattacharjee' : 'DAA - (10:30-12:00)' , 'Geetha V' : 'PC - (1:00-2:30), ACD - (10:30-12:00)', 'Anand Kumar' : 'PS - (9:00-10:30)', 'Anupama' : None, 'Vasudev' : 'WEB - (1:00-2:30)', 'Anitha' : 'DBMS - (9:00-10:30)'},
    'Friday' : {'G Ram Mohan Reddy' : 'DAA - (10:30-12:00)', 'Sowmya Kamath' : 'DS - (1:00-2:30)', 'Nagamma Patil' :'LA - (9:00-10:30)' , 'Sujan Gowda' : 'AI - (10:30-12:00)', 'Bhawana Rudra' : 'SE - (10:30-12:00)','Shrutilipi Bhattacharjee' : 'DSA - (9:00-10:30)' , 'Geetha V' : 'PC - (9:00-10:30)', 'Anand Kumar' : 'PS - (9:00-10:30)', 'Anupama' : 'OS - (10:30-12:00)', 'Vasudev' : None, 'Anitha' : None}
}

genetic_prof = {
    'Monday' : {'G Ram Mohan Reddy' : 'DAA - (2:30-4:00)', 'Sowmya Kamath' : 'DS - (10:30 - 12:00)', 'Nagamma Patil' : 'LA - (9:00-10:30)', 'Sujan Gowda' : None, 'Bhawana Rudra' : 'SE - (9:00-10:30), QC - (1:00-2:30)', 'Shrutilipi Bhattacharjee' : 'DAA - (10:30-12:00)', 'Geetha V' : 'PC - (1:00-2:30), ACD - (2:30-4:00)', 'Anand Kumar' : None, 'Anupama' : None, 'Vasudev' : 'WEB - (10:30-12:00)', 'Anitha' : 'DBMS - (1:00-2:30)'},
    'Tuesday' :{'G Ram Mohan Reddy' : 'DAA - (2:30-4:00)', 'Sowmya Kamath' : None, 'Nagamma Patil' :'LA - (1:00-2:30)' , 'Sujan Gowda' : 'AI - (9:00-10:30)', 'Bhawana Rudra' : 'QC - (1:00-2:30)', 'Shrutilipi Bhattacharjee' : 'DAA - (2:30-4:00)' , 'Geetha V' : 'PC - (10:30-12:00), ACD - (2:30-4:00)', 'Anand Kumar' : 'PS - (9:00-10:30)', 'Anupama' : None, 'Vasudev' : None, 'Anitha' : 'DBMS - (1:00-2:30'},
    'Wednesday' : {'G Ram Mohan Reddy' : 'DAA - (2:30-4:00)', 'Sowmya Kamath' : 'DS - (10:30 - 12:00)', 'Nagamma Patil' :None , 'Sujan Gowda' : 'AI - (9:00-10:30)', 'Bhawana Rudra' : None,'Shrutilipi Bhattacharjee' : 'DAA - (10:30-12:00)' , 'Geetha V' : 'PC - (9:00-10:30), ACD - (2:30-4:00)', 'Anand Kumar' : 'PS - (10:30-12:00)', 'Anupama' : 'OS - (10:30-12:00)', 'Vasudev' : 'WEB - (1:00-2:30)', 'Anitha' : None},
    'Thursday' : {'G Ram Mohan Reddy' : 'DAA - (2:30-4:00)', 'Sowmya Kamath' : None, 'Nagamma Patil' :'LA - (1:00-2:30)' , 'Sujan Gowda' : 'AI - (9:00-10:30)', 'Bhawana Rudra' : 'SE - (10:30-12:00), QC - (1:00-2:30)','Shrutilipi Bhattacharjee' : 'DSA - (9:00-12:00)' , 'Geetha V' : None, 'Anand Kumar' : 'PS - (9:00-10:30)', 'Anupama' : 'OS - (1:00-2:30)', 'Vasudev' : 'WEB - (2:30-4:00)', 'Anitha' : None},
    'Friday' : {'G Ram Mohan Reddy' : 'DAA - (2:30-4:00)', 'Sowmya Kamath' : None, 'Nagamma Patil' :None , 'Sujan Gowda' : None, 'Bhawana Rudra' : 'SE - (10:30-12:00), QC - (9:00-10:30)','Shrutilipi Bhattacharjee' : 'DAA - (1:00-2:30)' , 'Geetha V' : 'ACD - (1:00-2:30)', 'Anand Kumar' : 'PS - (2:30-4:00)', 'Anupama' : None, 'Vasudev' : None, 'Anitha' : 'DBMS - (2:30-4:00)'}
}

print(pd.DataFrame(dp_prof))
