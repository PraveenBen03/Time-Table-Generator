from elements import room, faculty, meetingTime, course, department

class Data:
    #JSON/Dicts/HashMaps
    rooms = {"R1":60, "R2":60, "R3":60}

    instructor = {"I1":"RMRG", "I2":"SK", "I3":"BR",
                    "I4":"DK", "I5":"SG"}

    meetingTime = {"MT1":"MWF 09:00-10:00",
                    "MT2":"MWFTh 12:00-13:00", 
                    "MT3":"TThW 09:00-10:00", 
                    "MT4":"TThM 11:00-12:00", 
                    "MT5":"MWF 13:00-14:00",
                    "MT6":"TWThF 10:00-11:00"}

    def __init__(self):
        self._room, self._meeting, self._instructors = [], [], []
        for i in self.rooms:
            self._room.append(room(i, self.rooms[i]))

        for i in self.meetingTime:
            self._meeting.append(meetingTime(i, self.meetingTime[i]))
        
        for i in self.instructor:
            self._instructors.append(faculty(i, self.instructor[i]))

        course1 = course("C1", "DAA", [self._instructors[0]], 50)
        course2 = course("C2", "DS", [self._instructors[1]], 50)
        course3 = course("C3", "QC", [self._instructors[2]], 50)
        course4 = course("C4", "LA", [self._instructors[3]], 50)
        course5 = course("C5", "AI", [self._instructors[4]], 50)
        
        self._course = [course1,course2,course3,course4,course5]

        dep1 = department("IT", self._course)
        self._dept = [dep1]

        self._numberOfClass = 0
        for i in range(len(self._dept)):
            self._numberOfClass += len(self._dept[i].getCourse())

    def getRoom(self): return self._room
    def getFaculty(self): return self._instructors
    def getCourse(self): return self._course
    def getDept(self): return self._dept
    def getClassNumber(self): return self._numberOfClass
    def getMeeting(self): return self._meeting

dp_dic2 = {'Monday':{2:'OS',3:'WEB',4:'ACD'},
'Tuesday':{1:'DSA',2:'DSA',3:'OS',4:'WEB'},
'Wednesday':{3:'DBMS',4:'OS'},
'Thursday':{3:'DBMS',4:'ACD'},
'Friday':{2:'WEB',3:'ACD',4:'DBMS'}}

import pandas as pd
dp_df2 = (pd.DataFrame(dp_dic2, index=[1, 2, 3, 4]).transpose())
dp_df2.columns = ['(9:00 - 10:30)', '(10:30 - 12:00)', '(1:00 - 2:30)', '(2:30 - 4:00)']
print(dp_df2)

gen_dic3 = {'Monday':{1:'SE',2:'DAA',3:'PC'},
'Tuesday':{1:'PS',2:'PC',4:'DAA'},
'Wednesday':{1:'PC',2:'PS'},
'Thursday':{1:'PS',2:'SE'},
'Friday':{2:'SE',3:'DAA',4:'PS'}}

gen_df3 = (pd.DataFrame(gen_dic3, index=[1, 2, 3, 4]).transpose())
gen_df3.columns = ['(9:00 - 10:30)', '(10:30 - 12:00)', '(1:00 - 2:30)', '(2:30 - 4:00)']
# print(dp_df2)