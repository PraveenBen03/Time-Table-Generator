from professor_classes import *
import professor_classes
from Create_store_prof import professor_list
import pandas as pd
import time

start_time = time.time()


def stable_matching(prof_lst, day):
    slots_booked = {}
    for i in range(len(prof_lst)):
        j = 0
        while prof_lst[i][0].sub not in slots_booked.values():
            if len(slots_booked) >= 4:
                return slots_booked
            pref = prof_lst[i][0].work.weekdays[day].preference_list[j]
            if pref in list(slots_booked.keys()):
                j += 1
            else:
                slots_booked[pref] = prof_lst[i][0].sub
    return slots_booked

slots_dic = {}
for day in range(5):
    each_day_availability = [(i[0], i[1][day]) for i in professor_list[:4]]
    professor_list_sorted = sorted(each_day_availability, key=(lambda x : x[1]))
    # print('day {}'.format(day + 1))
    # print(professor_list_sorted)
    # print()
    slots = stable_matching(professor_list_sorted, day)
    slots_dic[weekdays[day]] = slots



print(slots_dic)
greedy_df = pd.DataFrame(slots_dic)
greedy_df = greedy_df.swapaxes('index', 'columns')
greedy_df.columns = ['(9:00 - 10:30)', '(10:30 - 12:00)', '(1:00 - 2:30)', '(2:30 - 4:00)']
# print(df)


#
from tabulate import tabulate

print(tabulate(greedy_df, headers = 'keys', tablefmt = 'psql'))

end_time = time.time()
greedy_runtime = end_time - start_time

print("Runtime: {:.5f} seconds".format(runtime))




































# import tkinter as tk
# #
# # # Example timetable DataFrame
#
# # Create the GUI window
# window = tk.Tk()
# window.title("Timetable")
#
# # Create a Tkinter label to display the timetable
# timetable_label = tk.Label(window, text=df.to_string(index=False), font=("Arial", 12))
# timetable_label.pack()
#
# # Run the GUI main loop
# window.mainloop()