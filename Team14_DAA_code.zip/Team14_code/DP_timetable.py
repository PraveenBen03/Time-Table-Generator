import tkinter as tk
import copy
import tkinter as tk
import time
import pandas as pd

class TimeTableApp:
    def __init__(self, root, data):
        self.root = root
        self.root.title("Time Table")

        self.table_frame = tk.Frame(self.root)
        self.table_frame.pack(pady=10)

        self.data = data

        self.create_table()

    def create_table(self):
        # Create table headings
        headings = ["Time", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
        for i, heading in enumerate(headings):
            label = tk.Label(self.table_frame, text=heading, font=('Arial', 12, 'bold'))
            label.grid(row=0, column=i, padx=10, pady=5)

        # Create table rows with existing data
        for i, row in enumerate(self.data):
            for j, cell in enumerate(row):
                label = tk.Label(self.table_frame, text=cell, font=('Arial', 12))
                label.grid(row=i+1, column=j, padx=10, pady=5)
start_time = time.time()
def func(i,n,professor_list,professor_priority,slots_taken,slots_alloted,teacher_alloted):
    #print(i)
    global total_class_par_week
    global ans_no_of_teachers
    global ans
    global ans1
    global f_slots
    if i == n:
        if slots_alloted > ans_no_of_teachers:
            ans_no_of_teachers = slots_alloted
            
            #(li1)
            ans = copy.copy(teacher_alloted)
            #print("abcd",ans)
            f_slots=copy.copy(slots_taken)
            
        return 
    func(i+1,n,professor_list,professor_priority,slots_taken,slots_alloted,teacher_alloted)
    for w in professor_priority[i]:
        if slots_taken[w]==-1 and total_class_par_week[i]<3:
            slots_taken[w] = i
            teacher_alloted.append(i)
            
         
            func(i+1,n,professor_list,professor_priority,slots_taken,slots_alloted+1,teacher_alloted)
            slots_taken[w] = -1
            teacher_alloted.pop()
        else : func(i+1,n,professor_list,professor_priority,slots_taken,slots_alloted,teacher_alloted)
            
    
professor_list = [0,1,2,3,4]
dictt_prof_subjects = {0:"DAA",1:"DS",2:"QC",3:"LA",4:"AI"}

professor_priority = [[[1,2,3],[2,4,3],[3,4,2],[4,1,3],[2,4,1]],[[2],[2,4,3],[3,4,2],[1,1,3],[2,4,1]],[[2],[1],[2],[1],[2]],[[],[],[3],[4],[3]],[[2],[],[1,3],[4],[3]]]
nums_to_timings = {0:"8-9",1:"9-10",2:"10-11",3:"11-12",4:"13:14"}
global total_class_par_week
total_class_par_week = [0,0,0,0,0]
global ans_no_of_teachers
global ans
global ans1
global f_slots
data1 = [["9:00 - 10:00",None,None,None,None,None],["10:00 - 11:00",None,None,None,None,None],["11:00 - 12:00",None,None,None,None,None],["13:00 - 14:00",None,None,None,None,None],["14:00 - 15:00",None,None,None,None,None]]
for j in range(5):
    i = professor_priority[j]
    print("DAY :",j)
    slots_alloted = 0
    slots_taken = [-1,-1,-1,-1,-1,-1]
    teacher_alloted = []
    ans = []
    ans1 = []
    ans_no_of_teachers = -1;
    
    func(0,5,professor_list,i,slots_taken,slots_alloted,teacher_alloted)
    
    for k in ans:
        total_class_par_week[k]=total_class_par_week[k]+1
        data1[f_slots.index(k)][j+1] = dictt_prof_subjects[k]
        print(dictt_prof_subjects[k],nums_to_timings[f_slots.index(k)])
print("--- %s seconds ---" % (time.time() - start_time))                      

# Example usage
# root = tk.Tk()
# print(data1)
# Sample data
data = [
    ["9:00 - 10:00", "sexthath", "Science", "English", "History", "Geography"],
    ["10:00 - 11:00", "Science", "English", "Math", "Geography", "History"],
    ["11:00 - 12:00", "English", "Math", "Science", "History", "Geography"],
    ["13:00 - 14:00", "History", "Geography", "Science", "Math", "English"],
    ["14:00 - 15:00", "Geography", "History", "English", "Science", "Math"]
]

# app = TimeTableApp(root, data1)
# root.mainloop()

def get_sample_dic(data):
    data_dic = {}
    for hours in data:
        data_dic[hours[0]] = hours[1:]
    return data_dic

print('\n\n\n\n\n')
data_dic = get_sample_dic(data1)

dp_df = pd.DataFrame(data_dic, index=['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'])
dp_df.drop('9:00 - 10:00', axis=1, inplace=True)
dp_df.columns = ['(9:00 - 10:30)', '(10:30 - 12:00)', '(1:00 - 2:30)', '(2:30 - 4:00)']
print(dp_df.columns)


